package br.ifsp.edu.dsw3.anagrama;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnagramaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnagramaApplication.class, args);
	}

}
