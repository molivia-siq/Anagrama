package br.ifsp.edu.dsw3.anagrama;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnagramaApplicationTests {

	@Test
	void contextLoads() {
	}

}
